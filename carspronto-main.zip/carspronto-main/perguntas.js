criaCartao(
    'historia',
    'quem foi Mansa musa?',
    'O Mansa Muça, foi o nono mansa, que se traduz como "rei dos reis" ou "imperador", do Império do Mali, além de ser reconhecido como o homem mais rico da história nos últimos mil anos'
)

criaCartao(
    'duvida',
    'quem veio primeiro o ovo ou a galinha?',
    'galinha'
)

criaCartao(
    'duvida',
    'qual  a maior palavra o mundo?',
    'será o termo inglês: "methionylthreonylthereonyl(…) isoleucine". Este termo, que conta com nada menos do que 189.819 letras, é a designação química da maior proteína existente: a Titina'
)

criaCartao(
    'geografia',
    'qual a capital a africa?',
    'arica nao tem capital'
)